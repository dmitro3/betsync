def emoji():
    return {
    "ltc": "<:ltc:1339343445675868191>",
    "sol": "<:sol:1340981839497793556>",
    "btc": "<:sol:1340981839497793556>",
    "eth": "<:eth:1340981832799485985>",
    "usdt": "<:usdt:1340981835563401217>",
    "money": "<:money:1339696847622639707>",
    "highroller": "<:High_roller:1340292419811545108>",
    "generousgiver": "<:generous_giver:1340292410327961740>",
    "bigwinner": "<:Big_winner:1340292414211887185>",
    "loading": "<a:loading:1344611780638412811>",
    "stats": "<:Stats:1344014084580053076>",
    }